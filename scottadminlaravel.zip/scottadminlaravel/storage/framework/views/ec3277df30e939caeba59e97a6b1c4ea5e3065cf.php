<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Shinzo SAITO">
    <title>部門情報削除 | ScottAdminLaravel Sample</title>
    <link rel="stylesheet" href="/css/main.css" type="text/css">
</head>
<body>
    <header>
        <h1>部門情報削除</h1>
        <p><a href="/logout">ログアウト</a></p>
    </header>
    <nav id="breadcrumbs">
        <ul>
            <li><a href="/">TOP</a></li>
            <li><a href="/dept/showDeptList">部門リスト</a></li>
            <li>部門情報削除確認</li>
        </ul>
    </nav>
    <section>
        <p>
            以下の部門情報を削除します。<br>
            よろしければ、削除ボタンをクリックしてください。
        </p>
        <dl>
            <dt>ID</dt>
            <dd><?php echo e($dept->getId()); ?></dd>
            <dt>部門番号</dt>
            <dd><?php echo e($dept->getDpNo()); ?></dd>
            <dt>部門名</dt>
            <dd><?php echo e($dept->getDpName()); ?></dd>
            <dt>所在地</dt>
            <dd><?php echo e($dept->getDpLoc()); ?></dd>
        </dl>
        <form action="/dept/deptDelete" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" id="deleteDeptId" name="deleteDeptId" value="<?php echo e($dept->getId()); ?>">
            <button type="submit">削除</button>
        </form>
    </section>
</body>
</html><?php /**PATH C:\xampp\htdocs\ph35\scottadminlaravel\resources\views/dept/deptConfirmDelete.blade.php ENDPATH**/ ?>