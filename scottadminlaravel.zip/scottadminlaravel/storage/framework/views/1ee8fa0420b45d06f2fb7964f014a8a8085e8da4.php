<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Shinzo SAITO">
    <title>部門情報編集 | ScottAdminLaravel Sample</title>
    <link rel="stylesheet" href="/css/main.css" type="text/css">
</head>
<body>
    <header>
        <h1>部門情報編集</h1>
        <p><a href="/logout">ログアウト</a></p>
    </header>
    <nav id="breadcrumbs">
        <ul>
            <li><a href="/goTop">TOP</a></li>
            <li><a href="/dept/showDeptList">部門リスト</a></li>
            <li>部門情報編集</li>
        </ul>
    </nav>
    <?php if(isset($validationMsgs)): ?>
    <section id="errorMsg">
        <p>以下のメッセージをご確認ください。</p>
        <ul>
            <?php $__currentLoopData = $validationMsgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($msg); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </section>
    <?php endif; ?>
    <section>
        <p>
            情報を入力し、更新ボタンをクリックしてください。
        </p>
        <form action="/dept/deptEdit" method="post" class="box">
            <?php echo csrf_field(); ?>
            部門ID:&nbsp;<?php echo e($dept->getId()); ?><br>
            <input type="hidden" name="editDpId" value="<?php echo e($dept->getId()); ?>">
            <label for="editDpNo">
                部門番号&nbsp;<span class="required">必須</span>
                <input type="number" min="10" max="90" step="10" id="editDpNo" name="editDpNo" value="<?php echo e($dept->getDpNo()); ?>" required>
            </label><br>
            <label for="editDpName">
                部門名&nbsp;<span class="required">必須</span>
                <input type="text" id="editDpName" name="editDpName" value="<?php echo e($dept->getDpName()); ?>" required>
            </label><br>
            <label for="editDpLoc">
                所在地
                <input type="text" id="editDpLoc" name="editDpLoc" value="<?php echo e($dept->getDpLoc()); ?>">
            </label><br>
            <button type="submit">更新</button>
        </form>
    </section>
</body>
</html><?php /**PATH C:\xampp\htdocs\ph35\scottadminlaravel\resources\views/dept/deptEdit.blade.php ENDPATH**/ ?>