<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Soichiro SANO">
    <title>従業員情報リスト | ScottAdmin Sample</title>
    <link rel="stylesheet" href="/css/main.css" type="text/css">
</head>
<body>
    <header>
        <h1>従業員情報リスト</h1>
        <p><a href="/logout">ログアウト</a></p>
    </header>
    <nav id="breadcrumbs">
        <ul>
            <li><a href="/">TOP</a></li>
            <li>従業員情報リスト</li>
        </ul>
    </nav>
    <?php if(session("flashMsg")): ?>
    <section id="flashMsg">
        <p><?php echo e(session("flashMsg")); ?></p>
    </section>
    <?php endif; ?>
    <section>
        <p>
            新規登録は<a href="/emp/goEmpAdd">こちら</a>から
        </p>
    </section>
    <section>
        <table>
            <thead>
                <tr>
                    <th>従業員ID</th>
                    <th>従業員番号</th>
                    <th>従業員名</th>
                    <th>役職</th>
                    <th>上司番号</th>
                    <th>雇用日</th>
                    <th>給与</th>
                    <th>所属部門ID</th>
                    <th colspan="2">操作</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $empList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($emp->getId()); ?></td>
                    <td><?php echo e($emp->getEmNo()); ?></td>
                    <td><?php echo e($emp->getEmName()); ?></td>
                    <td><?php echo e($emp->getEmJob()); ?></td>
                    <td><?php echo e($emp->getEmMgr()); ?></td>
                    <td><?php echo e($emp->getEmHiredate()); ?></td>
                    <td><?php echo e($emp->getEmSal()); ?></td>
                    <td><?php echo e($emp->getDeptId()); ?></td>
                    <td>
                        <a href="/emp/prepareEmpEdit/<?php echo e($emp->getId()); ?>">編集</a>
                    </td>
                    <td>
                        <a href="/emp/confirmEmpDelete/<?php echo e($emp->getId()); ?>">削除</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="10">該当部門は存在しません。</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </section>
</body>
</html><?php /**PATH C:\xampp\htdocs\ph35\scottadminlaravel\resources\views/emp/empList.blade.php ENDPATH**/ ?>