<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Shinzo SAITO">
    <title>部門情報リスト | ScottAdminLaravel Sample</title>
    <link rel="stylesheet" href="/css/main.css" type="text/css">
</head>
<body>
    <header>
        <h1>部門情報リスト</h1>
        <p><a href="/logout">ログアウト</a></p>
    </header>
    <nav id="breadcrumbs">
        <ul>
            <li><a href="/goTop">TOP</a></li>
            <li>部門情報リスト</li>
        </ul>
    </nav>
    <?php if(session("flashMsg")): ?>
    <section id="flashMsg">
        <p><?php echo e(session("flashMsg")); ?></p>
    </section>
    <?php endif; ?>
    <section>
        <p>
            新規登録は<a href="/dept/goDeptAdd">こちら</a>から
        </p>
    </section>
    <section>
        <table>
            <thead>
                <tr>
                    <th>部門ID</th>
                    <th>部門番号</th>
                    <th>部門名</th>
                    <th>所在地</th>
                    <th colspan="2">操作</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $deptList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dpId => $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($dpId); ?></td>
                    <td><?php echo e($dept->getDpNo()); ?></td>
                    <td><?php echo e($dept->getDpName()); ?></td>
                    <td><?php echo e($dept->getDpLoc()); ?></td>
                    <td>
                        <a href="/dept/prepareDeptEdit/<?php echo e($dpId); ?>">編集</a>
                    </td>
                    <td>
                        <a href="/dept/confirmDeptDelete/<?php echo e($dpId); ?>">削除</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5">該当部門は存在しません。</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </section>
</body>
</html><?php /**PATH C:\xampp\htdocs\ph35\scottadminlaravel\resources\views/dept/deptList.blade.php ENDPATH**/ ?>