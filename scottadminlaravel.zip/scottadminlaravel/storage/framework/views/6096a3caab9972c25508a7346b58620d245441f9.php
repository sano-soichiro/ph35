<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Shinzo SAITO">
    <title>従業員情報編集 | ScottAdmin Sample</title>
    <link rel="stylesheet" href="/css/main.css" type="text/css">
</head>
<body>
    <header>
        <h1>従業員情報編集</h1>
        <p><a href="/logout">ログアウト</a></p>
    </header>
    <nav id="breadcrumbs">
        <ul>
            <li><a href="/">TOP</a></li>
            <li><a href="/emp/showEmpList">従業員リスト</a></li>
            <li>従業員情報編集</li>
        </ul>
    </nav>
    <?php if(isset($validationMsgs)): ?>
    <section id="errorMsg">
        <p>以下のメッセージをご確認ください。</p>
        <ul>
        <?php $__currentLoopData = $validationMsgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($msg); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </section>
    <?php endif; ?>
    <section>
        <p>情報を入力し、更新ボタンをクリックしてください。</p>
        <form action="/emp/empEdit" method="post" class="box">
        <?php echo csrf_field(); ?>
            従業員ID:&nbsp;<?php echo e($emp->getId()); ?><br>
            <input type="hidden" name="editEmpId" value="<?php echo e($emp->getId()); ?>">
            <label for="editEmpNo">
                従業員番号&nbsp;<span class="required">必須</span>
                <input type="number" min=1000 max=9999 id="editEmpNo" name="editEmpNo" value="<?php echo e($emp->getEmNo()); ?>" required>
            </label><br>
            <label for="editEmpName">
                従業員名&nbsp;<span class="required">必須</span>
                <input type="text" id="editEmpName" name="editEmpName" value="<?php echo e($emp->getEmName()); ?>" required>
            </label><br>
            <label for="editEmpJob">
                役職&nbsp;<span class="required">必須</span>
                <input type="text" id="editEmpJob" name="editEmpJob" value="<?php echo e($emp->getEmJob()); ?>" required>
            </label><br>
            <label for="editEmpMgr">
                上司&nbsp;<span class="required">必須</span>
                <select name="editEmpMgr" id="editEmpMgr" required>
                    <?php if($emp->getEmMgr() == 0): ?>
                    <option value="0" selected>0：上司なし</option>
                    <?php else: ?>
                    <option value="0">0：上司なし</option>
                    <?php endif; ?>
                    <?php $__currentLoopData = $empMgrList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mgr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($emp->getEmMgr() != 0 && $emp->getEmMgr() == $mgr[0]): ?>
                    <option value="<?php echo e($mgr[0]); ?>" selected><?php echo e($mgr[1] . ":" . $mgr[0]); ?></option>
                        <?php else: ?>
                    <option value="<?php echo e($mgr[0]); ?>"><?php echo e($mgr[1] . ":" . $mgr[0]); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label><br>
            <label for="editEmpHiredate">
                雇用日&nbsp;<span class="required">必須</span>
                <select name="year" id="year" required>
                    <option value="" selected>--</option>
                    <?php for($year= 2022; $year > 1980; $year--): ?>
                        <?php if($emp->getEmHiredateYear() == $year): ?>
                    <option value="<?php echo e($year); ?>" selected><?php echo e($year); ?></option>
                        <?php else: ?>
                    <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                        <?php endif; ?>
                    <?php endfor; ?>
                </select>
                <select name="month" id="month" required>
                    <option value="" selected>--</option>
                    <?php for($month = 1; $month < 12; $month++): ?>
                        <?php if($emp->getEmHiredateMonth() == $month): ?>
                    <option value="<?php echo e($month); ?>" selected><?php echo e($month); ?></option>
                        <?php else: ?>
                    <option value="<?php echo e($month); ?>"><?php echo e($month); ?></option>
                        <?php endif; ?>
                    <?php endfor; ?>
                </select>
                <select name="day" id="day" required>
                    <option value="" selected>--</option>
                    <?php for($day = 1; $day < 31; $day++ ): ?>
                        <?php if($emp->getEmHiredateDay() == $day): ?>
                    <option value="<?php echo e($day); ?>" selected><?php echo e($day); ?></option>
                        <?php else: ?>
                    <option value="<?php echo e($day); ?>"><?php echo e($day); ?></option>
                        <?php endif; ?>
                    <?php endfor; ?>
                </select>
            </label><br>
            <label for="editEmpSal">
                給与&nbsp;<span class="required">必須</span>
                <input type="number" min=0 id="editEmpSal" name="editEmpSal" value="<?php echo e($emp->getEmSal()); ?>" required>
            </label><br>
            <label for="editDpId">
                所属部門&nbsp;<span class="required">必須</span>
                <select name="editDeptId" id="editDeptId" required>
                    <option value="" selected>--</option>
                    <?php $__currentLoopData = $deptList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($emp->getDeptId() == $dept->getId()): ?>
                    <option value="<?php echo e($dept->getId()); ?>" selected><?php echo e($dept->getDpNo() . ":" . $dept->getDpName()); ?></option>
                        <?php else: ?>
                    <option value="<?php echo e($dept->getId()); ?>"><?php echo e($dept->getDpNo() . ":" . $dept->getDpName()); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label><br>
            <button type="submit">更新</button>
        </form>
    </section>
</body>
</html><?php /**PATH C:\xampp\htdocs\ph35\scottadminlaravel\resources\views/emp/empEdit.blade.php ENDPATH**/ ?>