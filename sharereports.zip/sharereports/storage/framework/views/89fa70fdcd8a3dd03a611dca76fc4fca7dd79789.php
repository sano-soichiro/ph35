<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/style.css" type="text/css">
    <title>deleteReport</title>
</head>
<body>
    <header>
        <h1>レポート削除</h1>
        <p>ログインユーザー: <?php echo e($loginUser['name']); ?></p>
        <p><a href="/logout">ログアウト</a></p>
    </header>
    <nav id="breadcrumbs">
        <ul>
            <li><a href="/reports/showList/<?php echo e(0); ?>">レポートリスト</a></li>
            <li><a href="/reports/detail/<?php echo e($reportDetail['report']->getId()); ?>">レポート詳細</a></li>
            <li>レポート削除確認</li>
        </ul>
    </nav>
    <section>
        <p>
            以下の部門情報を削除します。<br>
            よろしければ、削除ボタンをクリックしてください。
        </p>
        <dl>
        <dt>レポートID</dt>
            <dd><?php echo e($reportDetail['report']->getId()); ?></dd>
            <dt>報告者名 : 報告者メールアドレス</dt>
            <dd><?php echo e($reportDetail['user']->getUsName() . " : " . $reportDetail['user']->getUsMail()); ?></dd>
            <dt>作業日</dt>
            <dd><?php echo e($reportDetail['report']->getRpDate()); ?></dd>
            <dt>作業開始時刻</dt>
            <dd><?php echo e($reportDetail['report']->getRpTimeFrom()); ?></dd>
            <dt>作業終了時刻</dt>
            <dd><?php echo e($reportDetail['report']->getRpTimeTo()); ?></dd>
            <dt>作業種類</dt>
            <dd><?php echo e($reportDetail['reportcate']->getRcName()); ?></dd>
            <dt>作業内容</dt>
            <dd><?php echo nl2br(e($reportDetail['report']->getRpContent())); ?></dd>
            <dt>レポート登録日時</dt>
            <dd><?php echo e($reportDetail['report']->getRpCreatedAt()); ?></dd>
        </dl>
        <form action="/reports/delete" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" id="deleteRpId" name="deleteRpId" value="<?php echo e($reportDetail['report']->getId()); ?>">
            <button type="submit">削除</button>
        </form>
    </section>
</body>
</html><?php /**PATH C:\xampp\htdocs\ph35\sharereports\resources\views/reports/confirmDelete.blade.php ENDPATH**/ ?>