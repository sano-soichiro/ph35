<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <meta name="author" content="Shinzo SAITO">
    <title>ログイン | ShareReports</title>
    <link rel="stylesheet" href="/css/style.css" type="text/css">
</head>

<body>
    <h1>ログイン</h1>
    <?php if(isset($validationMsgs)): ?>
    <section id="errorMsg">
        <p>以下のメッセージをご確認ください。</p>
        <ul>
            <?php $__currentLoopData = $validationMsgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($msg); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </section>
    <?php endif; ?>
    <section>
        <p>
            メールアドレスとパスワードを入力し、ログインをクリックしてください。
        </p>
        <form action="/login" method="post">
            <?php echo csrf_field(); ?>
            <dl>
                <dt>メールアドレス</dt>
                <dd>
                    <input type="email" id="usMail" name="usMail" value="<?php echo e($usMail ?? ""); ?>" required>
                </dd>
                <dt>パスワード</dt>
                <dd>
                    <input type="password" id="loginPw" name="loginPw" required>
                </dd>
            </dl>
            <button type="submit">ログイン</button>
        </form>
    </section>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ph35\sharereports\resources\views/login.blade.php ENDPATH**/ ?>