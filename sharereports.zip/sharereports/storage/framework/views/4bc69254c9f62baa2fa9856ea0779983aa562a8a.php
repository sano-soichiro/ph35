<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/style.css" type="text/css">
    <title>ReportsList</title>
</head>
<body>
    <header>
        <h1>レポートリスト</h1>
        <p>ログインユーザー: <?php echo e($loginUser['name']); ?></p>
        <p><a href="/logout">ログアウト</a></p>
    </header>
    <nav id="breadcrumbs">
        <ul>
            <li>レポートリスト</li>
        </ul>
    </nav>
    <?php if(session("flashMsg")): ?>
    <section id="flashMsg">
        <p><?php echo e(session("flashMsg")); ?></p>
    </section>
    <?php endif; ?>
    <section>
        <p>
            新規登録は<a href="/reports/goAdd">こちら</a>から
        </p>
    </section>
    <section>
        <table>
            <thead>
                <tr>
                    <th>レポートID</th>
                    <th>作業日</th>
                    <th>報告者名</th>
                    <th>作業内容</th>
                    <th colspan="1">操作</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $reportList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rpId => $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($rpId); ?></td>
                    <td><?php echo e($report['report']->getRpDate()); ?></td>
                    <td><?php echo e($report['user']->getUsName()); ?></td>
                    <td><?php echo e($report['report']->getRpContent()); ?></td>
                    <td>
                        <a href="/reports/detail/<?php echo e($rpId); ?>">詳細</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">該当レポートは存在しません。</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </section>
    <section>
        <ul class="page">
            <li>
                <a class="<?php echo e($firstPage); ?>" href="/reports/showList/<?php echo e($nowPage-1); ?>">前へ</a>
            </li>
            <?php for($i=0; $i<$maxPage; $i++): ?>
            <li>
                <a class="<?php echo e($nowPage == $i ? 'now' : 'another'); ?>" href="/reports/showList/<?php echo e($i); ?>"><?php echo e($i+1); ?></a>
            </li>
            <?php endfor; ?>
            <li>
                <a class="<?php echo e($lastPage); ?>" href="/reports/showList/<?php echo e($nowPage+1); ?>">次へ</a>
            </li>
        </ul>
    </section>
</body>
</html><?php /**PATH C:\xampp\htdocs\ph35\sharereports\resources\views/reports/list.blade.php ENDPATH**/ ?>