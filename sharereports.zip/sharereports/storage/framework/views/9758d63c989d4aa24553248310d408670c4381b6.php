<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/style.css" type="text/css">
    <title>editReport</title>
</head>
<body>
    <header>
        <h1>レポート編集</h1>
        <p>ログインユーザー: <?php echo e($loginUser['name']); ?></p>
        <p><a href="/logout">ログアウト</a></p>
    </header>
    <nav id="breadcrumbs">
        <ul>
            <li><a href="/reports/showList/<?php echo e(0); ?>">レポートリスト</a></li>
            <li><a href="/reports/detail/<?php echo e($report->getId()); ?>">レポート詳細</a></li>
            <li>レポート編集</li>
        </ul>
    </nav>
    <?php if(isset($validationMsgs)): ?>
    <section id="errorMsg">
        <p>以下のメッセージをご確認ください。</p>
        <ul>
            <?php $__currentLoopData = $validationMsgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($msg); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </section>
    <?php endif; ?>
    <section>
        <p>
            情報を入力し、更新ボタンをクリックしてください。
        </p>
        <form action="/reports/edit" method="post" class="box">
            <?php echo csrf_field(); ?>
            レポートID:&nbsp;<?php echo e($report->getId()); ?><br>
            <input type="hidden" name="editId" value="<?php echo e($report->getId()); ?>" required>
            <label for="editRpTimeTo">
                作業日&nbsp;<span class="required">必須</span>
                <select name="editRpDateYear" id="editRpDateYear" required>
                    <option value="" selected>--</option>
                    <?php for($year = 2022; $year > 1980; $year--): ?>
                        <?php if($report->getRpDateYear() == $year): ?>
                    <option value="<?php echo e($year); ?>" selected><?php echo e($year); ?></option>
                        <?php else: ?>
                    <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                        <?php endif; ?>
                    <?php endfor; ?>
                </select>
                <select name="editRpDateMonth" id="editRpDateMonth" required>
                    <option value="" selected>--</option>
                    <?php for($month = 01; $month <= 12; $month++): ?>
                        <?php if($report->getRpDateMonth() == $month): ?>
                    <option value="<?php echo e($month); ?>" selected><?php echo e($month); ?></option>
                        <?php else: ?>
                    <option value="<?php echo e($month); ?>"><?php echo e($month); ?></option>
                        <?php endif; ?>
                    <?php endfor; ?>
                </select>
                <select name="editRpDateDay" id="editRpDateDay" required>
                    <option value="" selected>--</option>
                    <?php for($day = 01; $day <= 31; $day++): ?>
                        <?php if($report->getRpDateDay() == $day): ?>
                    <option value="<?php echo e($day); ?>" selected><?php echo e($day); ?></option>
                        <?php else: ?>
                    <option value="<?php echo e($day); ?>"><?php echo e($day); ?></option>
                        <?php endif; ?>
                    <?php endfor; ?>
                </select>
            </label><br>
            <label for="editRpTimeFrom">
                作業開始時刻&nbsp;<span class="required">必須</span>
                <input type="time" id="editRpTimeFrom" name="editRpTimeFrom" value="<?php echo e($report->getRpTimeFrom()); ?>" required>
            </label><br>
            <label for="editRpTimeTo">
                作業終了時刻&nbsp;<span class="required">必須</span>
                <input type="time" id="editRpTimeTo" name="editRpTimeTo" value="<?php echo e($report->getRpTimeTo()); ?>" required>
            </label><br>
            <label for="editReportcateId">
                作業種類&nbsp;<span class="required">必須</span>
                <select id="editReportcateId" name="editReportcateId" required>
                <?php $__currentLoopData = $reportcate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cateId => $repocate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($repocate->getId() != 0 && $repocate->getId() == $report->getReportcateId()): ?>
                <option value="<?php echo e($repocate->getId()); ?>" selected><?php echo e($repocate->getRcName()); ?></option>
                <?php else: ?>
                <option value="<?php echo e($repocate->getId()); ?>"><?php echo e($repocate->getRcName()); ?></option>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label><br>
            <label for="editRpContent">
                作業内容&nbsp;<span class="required">必須</span>
                <textarea id="editRpContent" name="editRpContent" cols="50" rows="20" required><?php echo e($report->getRpContent()); ?></textarea>
            </label><br>
            <button type="submit">更新</button>
        </form>
    </section>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ph35\sharereports\resources\views/reports/edit.blade.php ENDPATH**/ ?>