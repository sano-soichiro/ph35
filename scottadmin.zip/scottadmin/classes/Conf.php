<?php
/**
 * PH35 サンプル3 マスターテーブル管理　Src04/12
 *
 * @author Shinzo SAITO
 *
 * ファイル名=Conf.php
 * フォルダ=/ph35/scottadmin/classes/
 */

/**
 * 定数クラス
 */
class Conf{
    const DB_DNS = "mysql:host=localhost;dbname=ph35scott;chaset=utf8";
    const DB_USERNAME = "scott";
    const DB_PASSWORD = "tiger";
}
?>