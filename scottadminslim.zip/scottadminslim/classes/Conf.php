<?php
/**
 * PH35 サンプル5 マスターテーブル管理完版　Src02/20
 *
 * @author Shinzo SAITO
 *
 * ファイル名=Conf.php
 * フォルダ=/ph35/scottadminkan/classes/
 */
namespace LocalHalPH35\ScottAdminSlim\Classes;

/**
 * 定数クラス
 */
class Conf{
    const DB_DNS = "mysql:host=localhost;dbname=ph35scott;chaset=utf8";
    const DB_USERNAME = "scott";
    const DB_PASSWORD = "tiger";
}
