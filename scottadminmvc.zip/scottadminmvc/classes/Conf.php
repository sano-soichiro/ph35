<?php
/**
 * PH35 サンプル5 マスターテーブル管理MVC版　Src05/18
 *
 * @author Shinzo SAITO
 *
 * ファイル名=Conf.php
 * フォルダ=/ph35/scottadminmvc/classes/
 */
namespace LocalHalPH35\ScottAdminMVC\Classes;

/**
 * 定数クラス
 */
class Conf{
    const DB_DNS = "mysql:host=localhost;dbname=ph35scott;chaset=utf8";
    const DB_USERNAME = "scott";
    const DB_PASSWORD = "tiger";
}
