<?php
/**
* PH35 サンプル8 名前空間 Src06/08
* 名前空間とは
* 実行ファイル
*
* @author Shinzo SAITO
*
* ファイル名=useMainController.php
* フォルダ=/ph35/namespaces/
*/
require_once("classes/MainController.php");

use LocalHalPH35\Namespaces\classes\MainController;

$controller = new MainController();